<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FaceDescriptor;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Arr;

class AttendanceController extends Controller
{
    /**
     * Mark attendance by recognizing face
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function markAttendance(Request $request)
    {
        try {
            // Validate the request data
            $validator = Validator::make($request->all(), [
                'face_descriptor' => 'required|array',
                'face_descriptor.*' => 'numeric',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }
            
            $incomingFaceDescriptor = $request->face_descriptor;
            
            // Ensure the incoming face descriptor has exactly 128 elements
            if (count($incomingFaceDescriptor) !== 128) {
                return response()->json([
                    'success' => false,
                    'message' => 'Incoming face descriptor must contain exactly 128 numeric values',
                ], 422);
            }
            
            // Get all stored face descriptors from the database
            $storedFaceDescriptors = FaceDescriptor::with('user')->get();
            
            if ($storedFaceDescriptors->isEmpty()) {
                return response()->json([
                    'success' => false,
                    'message' => 'No face descriptors registered in the system',
                ], 404);
            }
            
            // Compare the incoming face descriptor with all stored descriptors
            $matchedUser = null;
            $minDistance = PHP_FLOAT_MAX;
            
            foreach ($storedFaceDescriptors as $storedDescriptor) {
                $storedDescriptorArray = $storedDescriptor->face_descriptor;
                
                // Calculate Euclidean distance between descriptors
                $distance = $this->calculateEuclideanDistance($incomingFaceDescriptor, $storedDescriptorArray);
                
                // If this distance is smaller than the current minimum, update the match
                if ($distance < $minDistance) {
                    $minDistance = $distance;
                    // Set threshold for considering a match (this can be adjusted based on accuracy needs)
                    if ($distance < 0.6) { // Threshold can be tuned based on testing
                        $matchedUser = $storedDescriptor->user;
                    }
                }
            }
            
            if ($matchedUser) {
                // Mark attendance for the matched user
                // Here you would typically create an attendance record
                // For now, just return success with user info
                
                return response()->json([
                    'success' => true,
                    'message' => 'Attendance marked successfully',
                    'data' => [
                        'user' => [
                            'id' => $matchedUser->id,
                            'name' => $matchedUser->name,
                            'email' => $matchedUser->email,
                        ],
                        'confidence' => round((1 - $minDistance) * 100, 2), // Convert distance to confidence percentage
                        'distance' => round($minDistance, 4),
                    ]
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'No matching face found in the system',
                ], 404);
            }

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to process attendance',
                'error' => $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Calculate Euclidean distance between two face descriptors
     *
     * @param array $desc1
     * @param array $desc2
     * @return float
     */
    private function calculateEuclideanDistance($desc1, $desc2)
    {
        if (count($desc1) !== count($desc2)) {
            throw new \InvalidArgumentException('Face descriptors must have the same length');
        }
        
        $sum = 0;
        for ($i = 0; $i < count($desc1); $i++) {
            $diff = $desc1[$i] - $desc2[$i];
            $sum += $diff * $diff;
        }
        
        return sqrt($sum);
    }
    
    /**
     * Get attendance records for a user
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getUserAttendance(Request $request)
    {
        try {
            $user = Auth::user();
            
            // In a real implementation, you would have an Attendance model to track attendance records
            // For now, we'll just return a placeholder response
            
            return response()->json([
                'success' => true,
                'message' => 'Attendance records retrieved successfully',
                'data' => [
                    'user_id' => $user->id,
                    'attendance_records' => [] // Placeholder for actual attendance records
                ]
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve attendance records',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
