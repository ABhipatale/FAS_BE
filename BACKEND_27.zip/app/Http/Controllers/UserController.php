<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    /**
     * Register a new user
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function register(Request $request)
    {
        try {
            // Validate the request data
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255',
                'email' => 'required|email|unique:users,email|max:255',
                'role' => ['required', Rule::in(['admin', 'user', 'superadmin', 'employee', 'attendanceapp'])],
                'password' => 'required|string|min:6',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            // Get the authenticated user to get their company_id (if registering from within company)
            $authUser = $request->user();
            $companyId = $authUser ? $authUser->company_id : null;
            
            // Create the user
            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'role' => $request->role,
                'password' => $request->password, // This will be hashed by the User model
                'face_descriptor' => null, // Will be set during face registration
                'company_id' => $companyId, // Assign company if registering from within company
            ]);

            return response()->json([
                'success' => true,
                'message' => 'User registered successfully',
                'data' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'role' => $user->role,
                    'created_at' => $user->created_at,
                ]
            ], 201);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Registration failed',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Store a newly created user in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            // Validate the request data
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255',
                'email' => 'required|email|unique:users,email|max:255',
                'address' => 'nullable|string|max:255',
                'phone' => 'nullable|string|max:20',
                'sex' => 'nullable|string|in:Male,Female,Other',
                'age' => 'nullable|integer|min:18|max:100',
                'dob' => 'nullable|date',
                'position' => 'nullable|string|max:100',
                'shift_id' => 'nullable|exists:shifts,id',
                'password' => 'required|string|min:6',
                // attendanceapp = kiosk-only account: the app exposes just the face
                // attendance screen to it, no dashboard and no other routes.
                'role' => ['nullable', Rule::in(['admin', 'user', 'superadmin', 'employee', 'attendanceapp'])],
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            // Get the authenticated user to get their company_id
            $authUser = $request->user();
            
            // Create the user
            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'address' => $request->address,
                'phone' => $request->phone,
                'sex' => $request->sex,
                'age' => $request->age,
                'dob' => $request->dob,
                'position' => $request->position,
                'shift_id' => $request->shift_id,
                'role' => $request->role ?? 'employee', // Default to employee role
                'password' => $request->password, // This will be hashed by the User model
                'face_descriptor' => null, // Will be set during face registration
                'company_id' => $authUser->company_id, // Assign the same company as the creator
            ]);

            // Load the shift relationship
            $user->load('shift');

            return response()->json([
                'success' => true,
                'message' => 'Employee created successfully',
                'data' => $user
            ], 201);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create employee',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get all users
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try {
            // Check if the authenticated user is an admin
            $user = $request->user();
            if (!$user || !($user->isAdmin() || $user->isSuperAdmin())) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized access'
                ], 403);
            }
            
            // Check database connectivity
            \DB::connection()->getPdo();
            
            // Filter users by company.
            // withCount gives face_descriptors_count, which is the real source of
            // truth for face registration - the users.face_descriptor column is
            // never written to by the registration flow.
            $users = User::where('company_id', $user->company_id)
                        ->with('shift')
                        ->withCount('faceDescriptors')
                        ->get();
            
            return response()->json([
                'success' => true,
                'data' => $users
            ]);
        } catch (\PDOException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Database error: ' . $e->getMessage()
            ], 500);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch users: ' . $e->getMessage(),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get a specific user
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try {
            $authUser = request()->user();

            // Find user within the same company. A user can always read their
            // own record - company scoping alone locks out legacy accounts with
            // no company_id, which breaks the profile page for them.
            $query = User::where('id', $id)
                       ->with('shift')
                       ->withCount('faceDescriptors');

            if ((int) $id !== (int) $authUser->id) {
                $query->where('company_id', $authUser->company_id);
            }

            $user = $query->first();
            
            if (!$user) {
                return response()->json([
                    'success' => false,
                    'message' => 'User not found or unauthorized access'
                ], 404);
            }

            return response()->json([
                'success' => true,
                'data' => $user
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch user',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Login user
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request)
    {
        try {
            // Validate the request data
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'password' => 'required|string',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            // Find user by email
            $user = User::where('email', $request->email)->first();
            
            if (!$user || !Hash::check($request->password, $user->password)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid credentials'
                ], 401);
            }

            // Revoke all existing tokens
            $user->tokens()->delete();
            
            // Create new token
            $token = $user->createToken('auth-token')->plainTextToken;
            
            return response()->json([
                'success' => true,
                'message' => 'Login successful',
                'data' => [
                    'user' => [
                        'id' => $user->id,
                        'name' => $user->name,
                        'email' => $user->email,
                        'role' => $user->role,
                    ],
                    'token' => $token,
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Login failed',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Logout user
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function logout(Request $request)
    {
        try {
            // Revoke the token that was used to authenticate the request
            $request->user()->currentAccessToken()->delete();
            
            return response()->json([
                'success' => true,
                'message' => 'Logout successful'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Logout failed',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get authenticated user
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function me(Request $request)
    {
        try {
            $user = $request->user();
            
            if ($user) {
                return response()->json([
                    'success' => true,
                    'data' => [
                        'user' => [
                            'id' => $user->id,
                            'name' => $user->name,
                            'email' => $user->email,
                            'role' => $user->role,
                        ]
                    ]
                ]);
            }
            
            return response()->json([
                'success' => false,
                'message' => 'Not authenticated'
            ], 401);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to get user data',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update an existing user
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {
            $authUser = $request->user();

            // Same rule as show(): editing yourself is always allowed, editing
            // anyone else stays inside your own company.
            $query = User::where('id', $id);

            if ((int) $id !== (int) $authUser->id) {
                $query->where('company_id', $authUser->company_id);
            }

            $user = $query->first();

            if (!$user) {
                return response()->json([
                    'success' => false,
                    'message' => 'User not found or unauthorized access'
                ], 404);
            }

            // Validate the request data
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255',
                'email' => ['required', 'email', 'max:255', Rule::unique('users')->ignore($id)],
                'address' => 'nullable|string|max:255',
                'phone' => 'nullable|string|max:20',
                'sex' => 'nullable|string|in:Male,Female,Other',
                'age' => 'nullable|integer|min:18|max:100',
                'dob' => 'nullable|date',
                'position' => 'nullable|string|max:100',
                'shift_id' => 'nullable|exists:shifts,id',
                'password' => 'nullable|string|min:6', // Optional - only update if provided
                // attendanceapp = kiosk-only account: the app exposes just the face
                // attendance screen to it, no dashboard and no other routes.
                'role' => ['nullable', Rule::in(['admin', 'user', 'superadmin', 'employee', 'attendanceapp'])],
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            // Update user fields
            $user->name = $request->name;
            $user->email = $request->email;
            $user->address = $request->address ?? $user->address;
            $user->phone = $request->phone ?? $user->phone;
            $user->sex = $request->sex ?? $user->sex;
            $user->age = $request->age ?? $user->age;
            $user->dob = $request->dob ?? $user->dob;
            $user->position = $request->position ?? $user->position;
            $user->shift_id = $request->shift_id ?? $user->shift_id;

            // Only admins may change a role. Without this any signed-in user
            // could PUT their own record with role=admin and escalate.
            if ($request->filled('role') && in_array($authUser->role, ['admin', 'superadmin'])) {
                $user->role = $request->role;
            }
            
            // Only update password if provided
            if ($request->filled('password')) {
                $user->password = $request->password; // Will be hashed by User model
            }
            
            $user->save();

            // Load the shift relationship
            $user->load('shift');

            return response()->json([
                'success' => true,
                'message' => 'Employee updated successfully',
                'data' => $user
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update employee',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete a user (admin only).
     *
     * The frontend has always called DELETE /users/{id}, but no such route
     * existed - deletions silently failed. Attendance and face descriptors are
     * removed by the foreign keys' cascade.
     */
    public function destroy(Request $request, $id)
    {
        try {
            $authUser = $request->user();

            if (!$authUser || !in_array($authUser->role, ['admin', 'superadmin'])) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized - administrators only',
                ], 403);
            }

            if ((int) $id === (int) $authUser->id) {
                return response()->json([
                    'success' => false,
                    'message' => 'You cannot delete your own account',
                ], 422);
            }

            $user = User::where('id', $id)
                        ->where('company_id', $authUser->company_id)
                        ->first();

            if (!$user) {
                return response()->json([
                    'success' => false,
                    'message' => 'User not found or unauthorized access',
                ], 404);
            }

            // Only a superadmin may remove another administrator
            if (in_array($user->role, ['admin', 'superadmin']) && $authUser->role !== 'superadmin') {
                return response()->json([
                    'success' => false,
                    'message' => 'Only a super administrator can delete an administrator account',
                ], 403);
            }

            $name = $user->name;
            $user->delete();

            return response()->json([
                'success' => true,
                'message' => "{$name} was deleted",
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete user',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
