<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FaceDescriptor;
use App\Models\User;
use App\Models\Attendance;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Arr;
use Carbon\Carbon;

class AttendanceController extends Controller
{
    /**
     * Mark attendance by recognizing face
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function markAttendance(Request $request)
    {
        try {
            // Punching is a device action, not a self-service one. Only the
            // attendance kiosk (attendanceapp) and admins may submit a face;
            // an employee must never be able to mark attendance from their own
            // login, which is exactly what the UI route block mirrors.
            $authUser = $request->user();

            if (!$authUser || !in_array($authUser->role, ['attendanceapp', 'admin', 'superadmin'])) {
                return response()->json([
                    'success' => false,
                    'message' => 'This account cannot mark attendance. Please use the attendance kiosk.',
                ], 403);
            }

            // Validate the request data
            $validator = Validator::make($request->all(), [
                'face_descriptor' => 'required|array',
                'face_descriptor.*' => 'numeric',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }
            
            $incomingFaceDescriptor = $request->face_descriptor;
            
            // Ensure the incoming face descriptor has exactly 128 elements
            if (count($incomingFaceDescriptor) !== 128) {
                return response()->json([
                    'success' => false,
                    'message' => 'Incoming face descriptor must contain exactly 128 numeric values',
                ], 422);
            }
            
            // Get all stored face descriptors from the database
            $storedFaceDescriptors = FaceDescriptor::with('user')->get();
            
            if ($storedFaceDescriptors->isEmpty()) {
                return response()->json([
                    'success' => false,
                    'message' => 'No face descriptors registered in the system',
                ], 404);
            }
            
            // Compare the incoming face descriptor with all stored descriptors
            $matchedUser = null;
            $minDistance = PHP_FLOAT_MAX;
            $bestMatchDescriptor = null;
            
            foreach ($storedFaceDescriptors as $storedDescriptor) {
                $storedDescriptorArray = $storedDescriptor->face_descriptor;
                
                // Calculate Euclidean distance between descriptors
                $distance = $this->calculateEuclideanDistance($incomingFaceDescriptor, $storedDescriptorArray);
                
                // If this distance is smaller than the current minimum, update the match
                if ($distance < $minDistance) {
                    $minDistance = $distance;
                    $bestMatchDescriptor = $storedDescriptor;
                }
            }
            
            // Only consider it a match if distance is below threshold AND the user has a registered face
            if ($minDistance < 0.5 && $bestMatchDescriptor) { // Changed from 0.6 to 0.5 for 50% confidence
                $matchedUser = $bestMatchDescriptor->user;
                
                // Verify that this user actually has a registered face descriptor
                $userFaceDescriptors = FaceDescriptor::where('user_id', $matchedUser->id)->count();
                if ($userFaceDescriptors === 0) {
                    // User exists but has no registered face descriptors - this shouldn't happen but let's be safe
                    $matchedUser = null;
                }
            }
            
            if ($matchedUser) {
                // Check if the matched user belongs to the same company as the authenticating user (for security)
                $authUser = $request->user();
                if ($authUser && $matchedUser->company_id !== $authUser->company_id) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Unauthorized: User does not belong to your company',
                    ], 403);
                }
                
                // Check if attendance for today already exists
                $today = Carbon::today();
                $existingAttendance = Attendance::where('user_id', $matchedUser->id)
                    ->whereDate('date', $today)
                    ->first();

                if ($existingAttendance) {
                    // If already punched in today, just update punch-out time
                    if (!$existingAttendance->punch_out_time) {
                        $existingAttendance->update([
                            'punch_out_time' => Carbon::now(),
                            'status' => 'present'
                        ]);
                        
                        return response()->json([
                            'success' => true,
                            'message' => 'Attendance updated successfully',
                            'data' => [
                                'user' => [
                                    'id' => $matchedUser->id,
                                    'name' => $matchedUser->name,
                                    'email' => $matchedUser->email,
                                ],
                                'action' => 'punch_out',
                                'punch_out_time' => Carbon::now()->format('Y-m-d H:i:s'),
                                'confidence' => round((1 - $minDistance) * 100, 2),
                                'distance' => round($minDistance, 4),
                            ]
                        ]);
                    } else {
                        return response()->json([
                            'success' => false,
                            'message' => 'Attendance already recorded for today',
                        ], 409);
                    }
                } else {
                    // Create new attendance record with punch-in time
                    $punchInTime = Carbon::now();
                    
                    // Check if user has a shift assigned
                    if (!$matchedUser->shift || !$matchedUser->shift->punch_in_time) {
                        // No shift assigned or no shift start time, mark as present without late check
                        $attendance = Attendance::create([
                            'user_id' => $matchedUser->id,
                            'date' => $today,
                            'punch_in_time' => $punchInTime,
                            'status' => 'present',
                            'late_mark' => false,
                            'company_id' => $matchedUser->company_id
                        ]);
                        
                        return response()->json([
                            'success' => true,
                            'message' => 'Attendance marked successfully',
                            'data' => [
                                'user' => [
                                    'id' => $matchedUser->id,
                                    'name' => $matchedUser->name,
                                    'email' => $matchedUser->email,
                                ],
                                'action' => 'punch_in',
                                'punch_in_time' => $punchInTime->format('Y-m-d H:i:s'),
                                'confidence' => round((1 - $minDistance) * 100, 2),
                                'distance' => round($minDistance, 4),
                                'late_mark' => false
                            ]
                        ]);
                    }
                    
                    // Calculate shift start time for today
                    $shiftStartTime = Carbon::createFromFormat('H:i:s', $matchedUser->shift->punch_in_time);
                    $shiftStartToday = Carbon::today()->setTimeFromTimeString($matchedUser->shift->punch_in_time);
                    
                    // Check if punch-in is more than 30 minutes late
                    $isLate = $punchInTime->gt($shiftStartToday->copy()->addMinutes(30));
                    
                    $attendance = Attendance::create([
                        'user_id' => $matchedUser->id,
                        'date' => $today,
                        'punch_in_time' => $punchInTime,
                        'status' => $isLate ? 'late' : 'present',
                        'late_mark' => $isLate,
                        'company_id' => $matchedUser->company_id
                    ]);

                    return response()->json([
                        'success' => true,
                        'message' => $isLate ? 'Attendance marked as late' : 'Attendance marked successfully',
                        'data' => [
                            'user' => [
                                'id' => $matchedUser->id,
                                'name' => $matchedUser->name,
                                'email' => $matchedUser->email,
                            ],
                            'action' => 'punch_in',
                            'punch_in_time' => $punchInTime->format('Y-m-d H:i:s'),
                            'confidence' => round((1 - $minDistance) * 100, 2),
                            'distance' => round($minDistance, 4),
                            'late_mark' => $isLate,
                            'shift_start_time' => $shiftStartToday->format('Y-m-d H:i:s'),
                            'minutes_late' => $isLate ? $punchInTime->diffInMinutes($shiftStartToday) : 0
                        ]
                    ]);
                }
            } else {
                // Determine the reason for no match
                $message = 'Face not recognized. Please ensure your face is registered in the system.';
                
                // If we found a match but it was above threshold
                if ($bestMatchDescriptor && $minDistance >= 0.5) { // Changed from 0.6 to 0.5
                    $message = 'Face detected but confidence too low for attendance. Please try again or register your face.';
                }
                
                return response()->json([
                    'success' => false,
                    'message' => $message,
                    'distance' => round($minDistance, 4),
                    'threshold' => 0.6 // Changed from 0.6 to 0.5
                ], 404);
            }

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to process attendance',
                'error' => $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Calculate Euclidean distance between two face descriptors
     *
     * @param array $desc1
     * @param array $desc2
     * @return float
     */
    private function calculateEuclideanDistance($desc1, $desc2)
    {
        if (count($desc1) !== count($desc2)) {
            throw new \InvalidArgumentException('Face descriptors must have the same length');
        }
        
        $sum = 0;
        for ($i = 0; $i < count($desc1); $i++) {
            $diff = $desc1[$i] - $desc2[$i];
            $sum += $diff * $diff;
        }
        
        return sqrt($sum);
    }
    
    /**
     * Get attendance records for a user
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getUserAttendance(Request $request)
    {
        try {
            $user = Auth::user();
            
            // In a real implementation, you would have an Attendance model to track attendance records
            // For now, we'll just return a placeholder response
            
            return response()->json([
                'success' => true,
                'message' => 'Attendance records retrieved successfully',
                'data' => [
                    'user_id' => $user->id,
                    'attendance_records' => [] // Placeholder for actual attendance records
                ]
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve attendance records',
                'error' => $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Get attendance records for a specific user by ID
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $userId
     * @return \Illuminate\Http\Response
     */
    public function getUserAttendanceById(Request $request, $userId)
    {
        try {
            // Check if the authenticated user has permission to view this user's attendance
            $authUser = Auth::user();
            
            // Allow if the user is viewing their own attendance or is an admin/superadmin
            if ($authUser->id != $userId && !in_array($authUser->role, ['admin', 'superadmin'])) {
                return response()->json([
                    'success' => false,
                    'message' => 'Unauthorized to view this user\'s attendance',
                ], 403);
            }
            
            // Find the user whose attendance is being requested within the same company
            $user = User::where('id', $userId)
                        ->where('company_id', $authUser->company_id)
                        ->first();
            
            if (!$user) {
                return response()->json([
                    'success' => false,
                    'message' => 'User not found or unauthorized access',
                ], 404);
            }
            
            // Extract month and year from query parameters, default to current month/year
            $month = $request->query('month', date('n')); // Current month
            $year = $request->query('year', date('Y')); // Current year
            
            // Get real attendance data from the database for the specified user and month
            $monthlyAttendance = Attendance::where('user_id', $userId)
                ->whereYear('date', $year)
                ->whereMonth('date', $month)
                ->orderBy('date')
                ->get()
                ->map(function ($attendance) {
                    $hoursWorked = null;
                    if ($attendance->punch_in_time && $attendance->punch_out_time) {
                        $inTime = $attendance->punch_in_time;
                        $outTime = $attendance->punch_out_time;
                        $interval = $inTime->diff($outTime);
                        $hoursWorked = $interval->h + ($interval->i / 60);
                        $hoursWorked = number_format($hoursWorked, 2);
                    }
                    return [
                        'date' => $attendance->date->format('Y-m-d'),
                        'status' => $attendance->status,
                        'punch_in_time' => $attendance->punch_in_time ? $attendance->punch_in_time->format('H:i:s') : null,
                        'punch_out_time' => $attendance->punch_out_time ? $attendance->punch_out_time->format('H:i:s') : null,
                        'hours_worked' => $hoursWorked,
                    ];
                })
                ->toArray();
            
            // Generate weekly attendance data (last 7 days including today)
            $weeklyAttendance = Attendance::where('user_id', $userId)
                ->whereBetween('date', [Carbon::now()->subDays(6), Carbon::now()])
                ->orderBy('date')
                ->get()
                ->map(function ($attendance) {
                    $hoursWorked = null;
                    if ($attendance->punch_in_time && $attendance->punch_out_time) {
                        $inTime = $attendance->punch_in_time;
                        $outTime = $attendance->punch_out_time;
                        $interval = $inTime->diff($outTime);
                        $hoursWorked = $interval->h + ($interval->i / 60);
                        $hoursWorked = number_format($hoursWorked, 2);
                    }
                    return [
                        'date' => $attendance->date->format('Y-m-d'),
                        'status' => $attendance->status,
                        'punch_in_time' => $attendance->punch_in_time ? $attendance->punch_in_time->format('H:i:s') : null,
                        'punch_out_time' => $attendance->punch_out_time ? $attendance->punch_out_time->format('H:i:s') : null,
                        'hours_worked' => $hoursWorked,
                    ];
                })
                ->toArray();
            
            // Generate yearly attendance data (current year)
            $yearlyAttendance = Attendance::where('user_id', $userId)
                ->whereYear('date', $year)
                ->orderBy('date')
                ->get()
                ->map(function ($attendance) {
                    $hoursWorked = null;
                    if ($attendance->punch_in_time && $attendance->punch_out_time) {
                        $inTime = $attendance->punch_in_time;
                        $outTime = $attendance->punch_out_time;
                        $interval = $inTime->diff($outTime);
                        $hoursWorked = $interval->h + ($interval->i / 60);
                        $hoursWorked = number_format($hoursWorked, 2);
                    }
                    return [
                        'date' => $attendance->date->format('Y-m-d'),
                        'status' => $attendance->status,
                        'punch_in_time' => $attendance->punch_in_time ? $attendance->punch_in_time->format('H:i:s') : null,
                        'punch_out_time' => $attendance->punch_out_time ? $attendance->punch_out_time->format('H:i:s') : null,
                        'hours_worked' => $hoursWorked,
                    ];
                })
                ->toArray();
            
            return response()->json([
                'success' => true,
                'message' => 'Attendance records retrieved successfully',
                'data' => [
                    'user' => $user,
                    'monthly' => $monthlyAttendance,
                    'weekly' => $weeklyAttendance,
                    'yearly' => $yearlyAttendance,
                ]
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve attendance records',
                'error' => $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Get dashboard statistics
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getDashboardStats(Request $request)
    {
        try {
            $authUser = Auth::user();
            
            // Get total employees for the current company
            $totalEmployees = User::where('company_id', $authUser->company_id)->count();
            
            // Check if attendances table exists
            $attendanceTableExists = \Schema::hasTable('attendances');
            
            if ($attendanceTableExists) {
                // Get today's attendance stats
                $today = Carbon::today();
                $todayPresentCount = Attendance::where('company_id', $authUser->company_id)
                    ->whereDate('date', $today)
                    ->where('status', 'present')
                    ->count();
                
                $todayAbsentCount = $totalEmployees - $todayPresentCount;
                
                // Get weekly attendance data (last 7 days)
                $startDate = Carbon::now()->subDays(6); // Last 7 days including today
                $endDate = Carbon::now();
                
                $weeklyAttendanceData = [];
                $currentDate = clone $startDate;
                
                while ($currentDate <= $endDate) {
                    $dateStr = $currentDate->format('Y-m-d');
                    $dayName = $currentDate->format('D');
                    
                    $presentCount = Attendance::where('company_id', $authUser->company_id)
                        ->whereDate('date', $dateStr)
                        ->where('status', 'present')
                        ->count();
                    
                    $absentCount = $totalEmployees - $presentCount;
                    
                    $weeklyAttendanceData[] = [
                        'name' => $dayName,
                        'present' => $presentCount,
                        'absent' => $absentCount,
                        'date' => $dateStr
                    ];
                    
                    $currentDate->addDay();
                }
                
                // Get today's attendance list
                $todayAttendanceList = Attendance::where('company_id', $authUser->company_id)
                    ->whereDate('date', $today)
                    ->with('user')
                    ->get()
                    ->map(function ($attendance) {
                        return [
                            'id' => $attendance->id,
                            'name' => $attendance->user->name,
                            'shift' => $attendance->user->shift ? $attendance->user->shift->name : 'N/A',
                            'punchIn' => $attendance->punch_in_time ? $attendance->punch_in_time->format('h:i A') : 'N/A',
                            'punchOut' => $attendance->punch_out_time ? $attendance->punch_out_time->format('h:i A') : 'N/A',
                            'status' => $attendance->status
                        ];
                    });
            } else {
                // Fallback to mock data if table doesn't exist
                $todayPresentCount = 0;
                $todayAbsentCount = $totalEmployees;
                
                $weeklyAttendanceData = [
                    ['name' => 'Mon', 'present' => 0, 'absent' => $totalEmployees, 'date' => Carbon::now()->subDays(6)->format('Y-m-d')],
                    ['name' => 'Tue', 'present' => 0, 'absent' => $totalEmployees, 'date' => Carbon::now()->subDays(5)->format('Y-m-d')],
                    ['name' => 'Wed', 'present' => 0, 'absent' => $totalEmployees, 'date' => Carbon::now()->subDays(4)->format('Y-m-d')],
                    ['name' => 'Thu', 'present' => 0, 'absent' => $totalEmployees, 'date' => Carbon::now()->subDays(3)->format('Y-m-d')],
                    ['name' => 'Fri', 'present' => 0, 'absent' => $totalEmployees, 'date' => Carbon::now()->subDays(2)->format('Y-m-d')],
                    ['name' => 'Sat', 'present' => 0, 'absent' => $totalEmployees, 'date' => Carbon::now()->subDays(1)->format('Y-m-d')],
                    ['name' => 'Sun', 'present' => 0, 'absent' => $totalEmployees, 'date' => Carbon::now()->format('Y-m-d')],
                ];
                
                $todayAttendanceList = collect(); // Empty collection
            }
            
            return response()->json([
                'success' => true,
                'message' => 'Dashboard statistics retrieved successfully',
                'data' => [
                    'stats' => [
                        'totalEmployees' => $totalEmployees,
                        'todayPresent' => $todayPresentCount,
                        'todayAbsent' => $todayAbsentCount
                    ],
                    'attendanceData' => $weeklyAttendanceData,
                    'attendanceList' => $todayAttendanceList
                ]
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve dashboard statistics',
                'error' => $e->getMessage()
            ], 500);
        }
    }
    
    /**
     * Get raw attendance data without processing
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function getRawAttendanceData(Request $request)
    {
        try {
            $authUser = Auth::user();
            
            // Check if attendances table exists
            $attendanceTableExists = \Schema::hasTable('attendances');
            
            if (!$attendanceTableExists) {
                return response()->json([
                    'success' => false,
                    'message' => 'Attendance table does not exist',
                    'data' => []
                ], 404);
            }
            
            // Get filter parameters
            $filter = $request->query('filter', 'today'); // today, yesterday, week, month, custom
            $startDate = $request->query('start_date');
            $endDate = $request->query('end_date');

            $query = Attendance::with('user', 'user.shift');

            // Apply date filters. week/month are what the dashboard dropdown
            // sends - without them the query used to fall through and return
            // every record ever recorded.
            if ($filter === 'today') {
                $query->whereDate('date', Carbon::today());
            } elseif ($filter === 'yesterday') {
                $query->whereDate('date', Carbon::yesterday());
            } elseif ($filter === 'week') {
                $query->whereBetween('date', [
                    Carbon::today()->subDays(6)->toDateString(),
                    Carbon::today()->toDateString(),
                ]);
            } elseif ($filter === 'month') {
                $query->whereBetween('date', [
                    Carbon::today()->startOfMonth()->toDateString(),
                    Carbon::today()->endOfMonth()->toDateString(),
                ]);
            } elseif ($filter === 'custom' && $startDate && $endDate) {
                $query->whereBetween('date', [$startDate, $endDate]);
            }
            
            // Apply company filter to the query
            $query->where('company_id', $authUser->company_id);
            
            // Get raw attendance records
            $attendanceRecords = $query->get();
            
            return response()->json([
                'success' => true,
                'message' => 'Raw attendance data retrieved successfully',
                'data' => $attendanceRecords
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve raw attendance data',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
